<?php
	
	$mysqli = new mysqli("localhost","root","JhosepH2020","agro_tic_narino");
	if($mysqli){
		mysqli_set_charset($mysqli,'utf8');
	}
?>