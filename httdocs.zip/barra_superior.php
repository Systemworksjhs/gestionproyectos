<!-- Inicio barra superior -->
        <div class="container-fluid bg-dark px-5 d-none d-lg-block">
            <div class="row gx-0 pt-1">
                <div class="col-lg-12 text-center text-lg-start mb-2 mb-lg-0">
                    <a href="https://www.gov.co/" target="_blank" class="navbar-brand p-0 imagen-svg"> <img src="img/logo_govco.png" width="90" height="20">
                    </a>
                </div>
            </div>
        </div>
<!-- Fin barra superior -->
