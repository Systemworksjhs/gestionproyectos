<?php
	
    if($iniciativa=="Pera"){$iniciativa=1;}
    if($iniciativa=="Mora"){$iniciativa=2;}
    if($iniciativa=="Manzana"){$iniciativa=3;}
    if($iniciativa=="Fresa"){$iniciativa=4;}
    if($iniciativa=="Naranja"){$iniciativa=5;}
    if($iniciativa=="Mandarina"){$iniciativa=6;}
    if($iniciativa=="Lulo"){$iniciativa=7;}
    if($iniciativa=="Mango"){$iniciativa=8;}
    if($iniciativa=="Aguacate"){$iniciativa=9;}
    if($iniciativa=="Limón"){$iniciativa=10;}
    if($iniciativa=="Tomate de árbol"){$iniciativa=11;}
    if($iniciativa=="Melocotón"){$iniciativa=12;}
    if($iniciativa=="Piña"){$iniciativa=13;}
    if($iniciativa=="Lima"){$iniciativa=14;}
    if($iniciativa=="Remolacha"){$iniciativa=15;}
    if($iniciativa=="Zanahoria"){$iniciativa=16;}
    if($iniciativa=="Brocoli"){$iniciativa=17;}
    if($iniciativa=="Espinaca"){$iniciativa=18;}
    if($iniciativa=="Tomate de carne"){$iniciativa=19;}
    if($iniciativa=="Ajo"){$iniciativa=20;}
    if($iniciativa=="Cebolla"){$iniciativa=21;}
    if($iniciativa=="Pimentón"){$iniciativa=22;}
    if($iniciativa=="Esparrago"){$iniciativa=23;}
    if($iniciativa=="Maíz"){$iniciativa=24;}
    if($iniciativa=="Coliflor"){$iniciativa=25;}
    if($iniciativa=="Calabaza"){$iniciativa=26;}
    if($iniciativa=="Pepino"){$iniciativa=27;}
    if($iniciativa=="Haba"){$iniciativa=28;}
    if($iniciativa=="Apio"){$iniciativa=29;}
    if($iniciativa=="Perejil"){$iniciativa=30;}
    if($iniciativa=="Lechuga"){$iniciativa=31;}
    
    if($iniciativa=="Choclo"){$iniciativa=32;}
    if($iniciativa=="Uchuva"){$iniciativa=33;}
    if($iniciativa=="Papa"){$iniciativa=34;}
    if($iniciativa=="Cebolla Cabezona"){$iniciativa=35;}
    if($iniciativa=="Arveja"){$iniciativa=36;}
    if($iniciativa=="Frijol"){$iniciativa=37;}
    if($iniciativa=="Acelga"){$iniciativa=38;}
    if($iniciativa=="Repollo"){$iniciativa=39;}
    if($iniciativa=="Ulloco"){$iniciativa=40;}
    if($iniciativa=="Cilantro"){$iniciativa=41;}
    if($iniciativa=="Yuca"){$iniciativa=42;}
    if($iniciativa=="Platano"){$iniciativa=43;}
    if($iniciativa=="Banano"){$iniciativa=44;}
    
    if($iniciativa=="Ají"){$iniciativa=45;}
    if($iniciativa=="Arracacha"){$iniciativa=46;}
    if($iniciativa=="Cacao"){$iniciativa=47;}
    if($iniciativa=="Café"){$iniciativa=48;}
    if($iniciativa=="Caña"){$iniciativa=49;}
    if($iniciativa=="Chocolate"){$iniciativa=50;}
    if($iniciativa=="Fique"){$iniciativa=51;}
    if($iniciativa=="Granadilla"){$iniciativa=52;}
    if($iniciativa=="Gulupa"){$iniciativa=53;}
    if($iniciativa=="Habichuela "){$iniciativa=54;}
    if($iniciativa=="Maní"){$iniciativa=55;}
    if($iniciativa=="Maracuyá"){$iniciativa=56;}
    if($iniciativa=="Oca"){$iniciativa=57;}
    if($iniciativa=="Quinua"){$iniciativa=58;}
    if($iniciativa=="Sábila "){$iniciativa=59;}
    if($iniciativa=="Sacha inchi"){$iniciativa=60;}
    if($iniciativa=="Trigo"){$iniciativa=61;}
    if($iniciativa=="Guanabana"){$iniciativa=62;}
    if($iniciativa=="Guayaba"){$iniciativa=63;}
    if($iniciativa=="Plantas aromáticas"){$iniciativa=64;}
    
?>
