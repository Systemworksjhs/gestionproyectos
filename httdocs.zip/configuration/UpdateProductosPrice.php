<?php
    //require '../configuration/conection.php';
    //require '../configuration/funcscopy.php';
    //$stringJson=$_GET["jsonPreString2"];
    echo "Captura del jsons<br>";
?>

